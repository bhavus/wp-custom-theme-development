<?php get_header();?>

<section class="404-page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Page Not Found</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam eaque culpa minima nam quam quisquam modi, molestiae numquam quis id?</p>
            </div>
        </div>
    </div>
</section>

<?php get_footer();?>